#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define FILE_BIN "arq_bin2.bin"
#define TAM 39999
#include "fileToStructStudent_2.h"
#include "Student_2.h"

int main(){
FILE *ptr;
//FILE *ptr_stdin;

//le arquivo e escreve no arquivo binario
char c;

//ptr_stdin = fopen("1.in","r");//FIM
ptr = fopen(FILE_BIN, "wb");

//c = fgetc(stdin); //pega no stdin, pra testar mais rapido vou colocar um arquivo
//printf("fgetc pegou stdin\n");

//copiar o ptr_stdin no ptr
//contar numero de registros
//************************************************************************
//ESTA DANDO ERRO NA HORA DE PEGAR OS DADOS E COPIÁ-LOS PARA UM ARQ.BIN
//************************************************************************
int n_registros = 0;


//c = fgetc(ptr_stdin);//FIM
c = fgetc(stdin);//FIM
char x;

while(c != EOF){
    fputc(c, ptr);

    if(c == '\n'){
        n_registros++;
    }
    //c = fgetc(ptr_stdin);
    x = c;
    c = fgetc(stdin);
    if(x == '\n' && c == EOF){
        printf("ENTROU NO BREAK 1 VEZ, x = %c e c == %d\n",x,c);
        break;
    }

}
n_registros++;

//---------------------
//NOVA LOGICA PARA COPIAR ARQUIVO
/*
fseek(ptr_stdin,0,SEEK_END);
long int tamanho = ftell(ptr_stdin);
printf("TAMANHO:%ld\n",tamanho);
fseek(ptr_stdin,0,SEEK_SET);
int k;

//FILE *ptr2 = fopen("ficaComo.bin","wb");
int n_registros = 0;
for(k = 0; k < tamanho; k++){
    c = fgetc(ptr_stdin);
    if(c =='\n'){
        n_registros++;
    }
    fputc(c,ptr);
  //  fputc(c,ptr2);
}
n_registros++;


printf("\nK = %d\n",k);
//---------------------
*/


fclose(ptr);
#define N_STRUCTS 10
ptr = fopen(FILE_BIN, "rb");

student_t *student;
student = file_to_vector_of_struct_student(n_registros, ptr,N_STRUCTS);
imprimir_students(student,n_registros, 10, -10);

//printf("\nNUMERO DE BYTES ALOCADOS: %d\n",sizeof(n_registros*sizeof(student_t)));
//printf("\nNUMERO DE MEGABYTES ALOCADOS: %d na memoria RAM\n",n_registros*sizeof(student_t)/1000000);


//limpandoMemoria
/*
for(int i = 0;i<N_STRUCTS;i++){
    free(&student[i]);
}*/

fclose(ptr);
//fclose(ptr_stdin);

return 0;
}

//TIRAR \N FINAL DO ARQUIVO BINARIO COPIADO

/*
- compilando main com suas bibliotecas

gcc ma.c fileToStructStudent.c Student.c -o m2



- Inserindo arquivo 1.in por stdin no executavel m2:

get-content 1.in | ./m2
*/