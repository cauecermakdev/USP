

// DFS algorithm in C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Read_input.h"

struct node {
  int vertex;
  struct node* next;
};

struct node* createNode(int v);


struct quest{
    char questName[30];
    char questDescription[60];
};

void print_struct(struct quest *quest_nodes, int tamanho){

    for(int i=0; i<tamanho;i++){
        printf("%s\n",quest_nodes[i].questName);
        printf("%s\n",quest_nodes[i].questDescription);
    }
}

//VAI SER PASSADO UM graph.adjList[i]
void print_indice_adjList(struct node *adjList, int indice_adjList){
    struct node *temp = malloc(sizeof(struct node));
    while(adjList != NULL){
            printf("adjList->vertex[%d] = %d\n", indice_adjList,adjList->vertex);
            adjList = adjList->next;
    }
}

void ordena_indice_adjList(struct node* adjList, int numVertices)
{       
    struct node *temp = malloc(sizeof(struct node));
    struct node *tempi;
    struct node *tempj;
    //struct node *temp3;
    tempi = adjList;
    tempj = tempi;
    //for (int i = 0; adjList[i].next == NULL; i++)
    /*
    while(adjList != NULL){
        
        //if(adjList[i].next == NULL)break;
        
        //for (int j = i; adjList[j].next == NULL; j++){ 
        //acho que e adjList[j], dps eu vejo
       
        while(adjList->next != NULL){

            //printf("i > adjList[%d].vertex:%d\n",i,adjList.vertex);
            //printf("j > adjList[%d].vertex:%d\n",j,adjList[j].vertex);

             //if(adjList[j].next == NULL)break;

            if (adjList->vertex > adjList->next->vertex){
                //trocando vertex
                temp->vertex = adjList->vertex;
                adjList->vertex = adjList->next->vertex;
                adjList->next->vertex = temp->vertex;
            }

            adjList = adjList->next;

        }
        adjList = tempi->next;
        tempi = adjList;
        
    }*/

    //second version
    /*
     while(tempi != NULL){
        
        //if(adjList[i].next == NULL)break;
        
        //for (int j = i; adjList[j].next == NULL; j++){ 
        //acho que e adjList[j], dps eu vejo
       
        while(tempj->next != NULL){

            //printf("i > adjList[%d].vertex:%d\n",i,adjList.vertex);
            //printf("j > adjList[%d].vertex:%d\n",j,adjList[j].vertex);

             //if(adjList[j].next == NULL)break;

            if (tempj->vertex > tempj->next->vertex){
                //trocando vertex
                temp->vertex = tempj->vertex;
                tempj->vertex = tempj->next->vertex;
                tempj->next->vertex = temp->vertex;
              
            }

            tempj = tempj->next;

        }
        //adjList = tempi->next;
        //tempi = adjList;
        tempi = tempi->next;
        tempj = adjList;
        
    }*/
    

    //terceira versao
     while(tempi != NULL){
        
        //if(adjList[i].next == NULL)break;
        
        //for (int j = i; adjList[j].next == NULL; j++){ 
        //acho que e adjList[j], dps eu vejo
       
        while(tempj != NULL){

            //printf("i > adjList[%d].vertex:%d\n",i,adjList.vertex);
            //printf("j > adjList[%d].vertex:%d\n",j,adjList[j].vertex);

             //if(adjList[j].next == NULL)break;

            if (tempi->vertex > tempj->vertex){
                //trocando vertex
                temp->vertex = tempi->vertex;
                tempi->vertex = tempj->vertex;
                tempj->vertex = temp->vertex;
                
            }

            tempj = tempj->next;

        }
        //adjList = tempi->next;
        //tempi = adjList;
        tempi = tempi->next;
        tempj = tempi;
        
    }

}




struct Graph {
  int numVertices;
  int* visited;
  // We need int** to store a two dimensional array.
  // Similary, we need struct node** to store an array of Linked lists
  struct node** adjLists;
};  

void zera_visited(struct Graph *graph){
    for(int i=0; i< graph->numVertices;i++){
        graph->visited[i]=0;
    }
}

void print_quest_id(struct quest *quest_nodes, int vertex){
    printf("Quest{\n");
    printf("\tID='%d'\n",vertex);
    //fazer o teste [vertex-1]
    printf("\tname=%s",quest_nodes[vertex].questName);
    printf("\tdescription=%s",quest_nodes[vertex].questDescription);
    printf("}\n\n");
}

//tenho que mudar a logica do DFS para imprimir na ordem que o Léo quer
// DFS algo
void DFS(struct Graph* graph, int vertex, struct quest *quest_nodes) {
//printf("vertex:%d\n",vertex);
  struct node* adjList = graph->adjLists[vertex];
  struct node* temp = adjList;
    

    graph->visited[vertex] = 1;
    //printf("Visited %d \n", vertex);    
    print_quest_id(quest_nodes, vertex);

  while (temp != NULL) {
    int connectedVertex = temp->vertex;
    if (graph->visited[connectedVertex] == 0) {
      DFS(graph, connectedVertex, quest_nodes);
    }
    temp = temp->next;
  }
  //zera_visited(graph);//zera vetor visited no grafo
}

// Create a node
struct node* createNode(int v) {
  struct node* newNode = malloc(sizeof(struct node));
  newNode->vertex = v;
  newNode->next = NULL;
  return newNode;
}

// Create graph
struct Graph* createGraph(int vertices) {
  struct Graph* graph = malloc(sizeof(struct Graph));
  graph->numVertices = vertices;

  graph->adjLists = malloc(vertices * sizeof(struct node*));

  graph->visited = malloc(vertices * sizeof(int));

  int i;
  for (i = 0; i < vertices; i++) {
    graph->adjLists[i] = NULL;
    graph->visited[i] = 0;
  }
  return graph;
}

// Add edge
void addEdge(struct Graph* graph, int src, int dest) {
  // Add edge from src to dest
  struct node* newNode = createNode(dest);


    newNode->next = graph->adjLists[src];
    graph->adjLists[src] = newNode;
 
  // Add edge from dest to src
  /*newNode = createNode(src);
  newNode->next = graph->adjLists[dest];
  graph->adjLists[dest] = newNode;*/
}

// Print the graph
void printGraph(struct Graph* graph) {
  int v;
  for (v = 0; v < graph->numVertices; v++) {
    struct node* temp = graph->adjLists[v];
    printf("\n Adjacency list of vertex %d\n ", v);
    while (temp) {
      printf("%d -> ", temp->vertex);
      temp = temp->next;
    }
    printf("\n");
  }
}

void printAllAdjList(struct Graph *graph){
    for(int i = 0; i< graph->numVertices; i++){
        if(graph->adjLists[i]!=NULL){
            print_indice_adjList(graph->adjLists[i],i);
        }
    }
}

//ordena cada um dos vetores de adjList
void sort_nodes(struct Graph *graph){
    //ordenar cada um dos indices do adjList, que sao os vetores de node
    for(int i=0; i<graph->numVertices; i++ ){
        ordena_indice_adjList(graph->adjLists[i], graph->numVertices);
    }

}

void case1(){

    //caso de teste 1
  
  struct Graph* graph = createGraph(15);
  
  addEdge(graph, 0, 11);
  addEdge(graph, 10, 0);
  addEdge(graph, 0, 1);
  addEdge(graph, 1, 2);
  addEdge(graph, 0, 3);
  addEdge(graph, 3, 4);
  addEdge(graph, 10, 12);
  addEdge(graph, 10, 8);
  addEdge(graph, 8, 9);
  addEdge(graph, 9, 5);
  addEdge(graph, 5, 6);
  addEdge(graph, 6, 7);
  addEdge(graph, 12, 13);
  addEdge(graph, 13, 14);
  addEdge(graph, 4, 14);
  addEdge(graph, 2, 14);
  
  printGraph(graph);


//  DFS(graph, 8);

}

void case2(){

  //caso de teste 2
  
  struct Graph* graph = createGraph(13);
  
  addEdge(graph, 0, 11);
  addEdge(graph, 10, 0);
  addEdge(graph, 0, 1);
  addEdge(graph, 1, 2);
  //addEdge(graph, 1, 3);//adicionei
  addEdge(graph, 0, 3);
  addEdge(graph, 3, 4);
  addEdge(graph, 10, 12);
  addEdge(graph, 10, 8);
  addEdge(graph, 8, 9);
  addEdge(graph, 9, 5);
  addEdge(graph, 5, 6);
  addEdge(graph, 6, 7);
  //printf("entra\n");

   // DFS(graph, 0);
    printAllAdjList(graph);

    printf("\n>> ordena <<\n");
    sort_nodes(graph);

    printf("\n\nchama DFS\n");
    //DFS(graph, 0);
    printf("\n\n");
  
    //printAllAdjList(graph);

}

void case3(){

      struct Graph* graph = createGraph(5);
  
  addEdge(graph, 0, 1);
  addEdge(graph, 0, 2);
  addEdge(graph, 0, 3);
  addEdge(graph, 1, 2);
  addEdge(graph, 2, 4);
  
  //printGraph(graph);


 // DFS(graph, 0);

}




//#proximos passos
//salvar entradas de string em um vetor de structs
//rodar entradas de arestas
//ordenar
//imprimir no formato o vetor_struct[i_visited]



int main() {
    FILE *p_stdin;
    int nNodes=0,i,j,src,dest,nArestas;
    char *currentInput,c;
    currentInput = calloc(50,sizeof(char));

    //pega quantidade de nos do stdin
    //printf("digite a quantidade de nós:\n");
    readCurrentInput(stdin, currentInput);
    nNodes = atoi(currentInput);

    //scanf("%d",&nNodes);
    struct Graph* graph = createGraph(nNodes);
    
    //recebe strings e coloca em um vetor de structs
    struct quest *quest_nodes = calloc(nNodes,sizeof(struct quest));
    
    //recebe Nodes
    for(int z = 0; z < nNodes; z++){
        //le questName
        int count = 0;
        c = 39;
        //c = fgetc(stdin);
        while(c != '\n'){
            quest_nodes[z].questName[count] = c;
            count++;
            c = fgetc(stdin);
        }
        quest_nodes[z].questName[count] = 39;

        count = 0;
        c = fgetc(stdin);
        while(c != '\n'){
            quest_nodes[z].questDescription[count] = c;
            count++;
            c = fgetc(stdin);
        }
    }

    //perfecto
   // print_struct(quest_nodes,nNodes);


    //pega quantidade de arestas do stdin
    //printf("digite a quantidade de arestas:\n");
    //scanf("%d",&nArestas);
    
    readCurrentInput(stdin, currentInput);
    nArestas = atoi(currentInput);
    //printf("nArestas:%d\n",nArestas);
    //recebe conections
    for(i = 0; i < nArestas; i++){
        
        readCurrentInput(stdin, currentInput);
        int src = atoi(currentInput);
        //printf("%d ",src);
        
        readCurrentInput(stdin, currentInput);
        int dest = atoi(currentInput);
        //printf("%d\n",dest);

        addEdge(graph,src,dest);

    }

    //recebe nó inicial para a search
    readCurrentInput(stdin, currentInput);
    int noInicial = atoi(currentInput);

    //ordena 
    sort_nodes(graph);

    DFS(graph, noInicial, quest_nodes);
    //printAllAdjList(graph);

    //case2();


  return 0;
}