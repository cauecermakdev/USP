#include "Student_2.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void imprimir_students(student_t *student, int n_registros , int n_registros_imprimir, int pos){
    //printf("ENTRA no imprimir students\n");
    int i;
    int comeco_impressao = n_registros + pos-1; //qual estrutura quero começar a imprimir
    int imprimir_ate = comeco_impressao + n_registros_imprimir; 
    //for(i = comeco_impressao; i < imprimir_ate ; i++){
    for(i = 0; i < 10 ; i++){
        printf("nUSP: %d\nNOME: %s\nCURSO: %s\nNOTA: %.2f", student[i].nusp,student[i].nome, student[i].curso, student[i].nota);
        if(i != (n_registros_imprimir-1)){printf("\n\n");}
    }
}