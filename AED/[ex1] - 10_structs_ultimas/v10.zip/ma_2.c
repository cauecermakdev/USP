#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fileToStructStudent_2.h"
#include "Student_2.h"
#define FILE_BIN "arq_bin2.bin"

int main(){
FILE *ptr;
char c;
ptr = fopen(FILE_BIN, "wb");
int n_registros = 0;



c = fgetc(stdin);
char x;

while(c != EOF){
    fputc(c, ptr);

    if(c == '\n'){
        n_registros++;
    }
    //c = fgetc(ptr_stdin);
    x = c;
    c = fgetc(stdin);
    if(x == '\n' && c == EOF){
        printf("ENTROU NO BREAK 1 VEZ, x = %c e c == %d\n",x,c);
        break;
    }

}
n_registros++;


fclose(ptr);
#define N_STRUCTS 10
ptr = fopen(FILE_BIN, "rb");

student_t *student;
student = file_to_vector_of_struct_student(n_registros, ptr,N_STRUCTS);
imprimir_students(student,N_STRUCTS);

//limpandoMemoria

for(int i = 0;i<N_STRUCTS;i++){
    free(&student[i]);
}
free(student);

fclose(ptr);

return 0;
}

