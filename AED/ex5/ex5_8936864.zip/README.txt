Rode no windows

Execute o makefile (com o arquivo teste "1.txt" com todos arquivos na mesma pasta)