#ifndef READ_INPUT_FILE_H
#define READ_INPUT_FILE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define INF 999

void print_matrix(int **vertices,int ordem);
int read_i_line();

#endif //READ_INPUT_FILE